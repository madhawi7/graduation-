package com.example.myapplication.ui.Discover

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.myapplication.R
import android.annotation.SuppressLint
import android.widget.TextView


class DiscoverActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_discover)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.acticity_main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val textViewResult = findViewById<TextView>(R.id.textViewResult)

        // استقبال البيانات من MainActivity
        val selectedChips = intent.getStringArrayListExtra("selected_chips") ?: ArrayList<String>()
        val seekBarValue = intent.getIntExtra("seekBar_value", 0)

        // استخدام القيم المستلمة للبحث عن النتائج
        val results = searchResults(selectedChips, seekBarValue)

        // عرض النتائج للمستخدم
        displayResults(results)
    }

    // دالة للبحث عن النتائج بناءً على القيم
    private fun searchResults(selectedChips: List<String>, seekBarValue: Int): List<String> {
        // هنا، يمكنك تطبيق منطق البحث بناءً على القيم
        // على سبيل المثال، إذا كانت القيم المدخلة تتطابق مع بعض البيانات
        val allResults = listOf(
            "نتيجة 1",
            "نتيجة 2",
            "نتيجة 3"
        )  // يمكن أن تكون هذه بيانات تأتي من API أو قاعدة بيانات

        // مثلاً، نستعرض النتائج التي تتطابق مع المتطلبات
        return allResults.filter { result ->
            selectedChips.any { result.contains(it) }
        }
    }

    // دالة لعرض النتائج
    private fun displayResults(results: List<String>) {
        val textViewResult = findViewById<TextView>(R.id.textViewResult)
        if (results.isNotEmpty()) {
            val resultText = results.joinToString("\n")
            textViewResult.text = resultText
        } else {
            textViewResult.text = "There is no result for your criteria."
        }
    }
}

