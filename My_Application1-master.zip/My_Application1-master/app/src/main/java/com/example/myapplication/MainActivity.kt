package com.example.myapplication

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication.databinding.ActivityMainBinding
import android.content.Intent
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.myapplication.ui.Discover.DiscoverActivity
import com.google.android.material.chip.Chip


    class MainActivity : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_main)

            lateinit var binding: ActivityMainBinding


            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)

            val navView: BottomNavigationView = binding.navView

            val navController = findNavController(R.id.nav_host_fragment_activity_main)
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.
            val appBarConfiguration = AppBarConfiguration(
                setOf(
                    R.id.navigation_home, R.id.navigation_discover, R.id.navigation_profile
                )
            )
            setupActionBarWithNavController(navController, appBarConfiguration)
            navView.setupWithNavController(navController)



            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(
                    systemBars.left,
                    systemBars.top,
                    systemBars.right,
                    systemBars.bottom
                )
                insets
            }

            val seekBar = findViewById<SeekBar>(R.id.seekBar)
            val seekBarValue = seekBar.progress // قيمة SeekBar
            val chip1 = findViewById<Chip>(R.id.chi)
            val chip2 = findViewById<Chip>(R.id.chip2)
            val chip3 = findViewById<Chip>(R.id.chh)
            val chip4 = findViewById<Chip>(R.id.c)
            val chip5 = findViewById<Chip>(R.id.ch1)
            val chip6 = findViewById<Chip>(R.id.chip)
            val button4 = findViewById<Button>(R.id.button4)
            val button = findViewById<Button>(R.id.button)

            button.setOnClickListener {
                finish() // زر الرجوع يعمل بشكل مستقل الآن
            }

            button4.setOnClickListener {
                val selectedChips = mutableListOf<String>()

                if (chip1.isChecked) selectedChips.add(chip1.text.toString())
                if (chip2.isChecked) selectedChips.add(chip2.text.toString())
                if (chip3.isChecked) selectedChips.add(chip3.text.toString())
                if (chip4.isChecked) selectedChips.add(chip4.text.toString())
                if (chip5.isChecked) selectedChips.add(chip5.text.toString())
                if (chip6.isChecked) selectedChips.add(chip6.text.toString())

                val seekBarValue = seekBar.progress

                if (selectedChips.isNotEmpty()) {
                    val intent = Intent(this,DiscoverActivity::class.java)
                    intent.putStringArrayListExtra("selected_chips", ArrayList(selectedChips))
                    intent.putExtra("seekBar_value", seekBarValue)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "please choose at least one choice", Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
