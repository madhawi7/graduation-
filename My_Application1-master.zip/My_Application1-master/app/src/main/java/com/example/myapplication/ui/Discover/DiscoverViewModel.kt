package com.example.myapplication.ui.Discover

import androidx.lifecycle.ViewModel

class DiscoverViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}